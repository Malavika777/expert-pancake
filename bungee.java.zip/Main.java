import java.util.Scanner;
class Main{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int age=in.nextInt();
        int wght=in.nextInt();
        if(age>=12){
            if(wght>=40){
                if(wght<=110){
                    System.out.println("eligible to jump");
                }
                else
                {
                    System.out.println("extra ropes will be provoided");
                }
            }
        }
        else{
            System.out.println("not eligible to jump");
        }
    }
}
	

